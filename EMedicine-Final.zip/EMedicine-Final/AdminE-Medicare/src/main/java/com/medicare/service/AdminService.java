package com.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.medicare.bean.Admin;
import com.medicare.repository.AdminRepository;





@Scope("singleton")
@Service("adminService")
public class AdminService implements AdminServiceimp{

	@Autowired
	@Qualifier("adminRepository")
	private AdminRepository repo;
	
	@Override
	public List<Admin> findAll() {
		return repo.findAll();
	}
	@Override
	public Admin findByUsername(String username) {
		return repo.username(username);
	}
	@Override
	public void save(Admin admin) {
		repo.save(admin);
		
	}
	@Override
	public Admin findByUsernameAndPassword(String username, String password) {
		return repo.findByUsernameAndPassword(username, password);
	}
	
	
}
package com.medicare.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import com.medicare.bean.User;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import java.util.Collections;
import java.util.List;

@FeignClient(name = "UserE-Medicare") // Name of the user service you want to consume
public interface UserServiceProxy {

    @PostMapping(value = "/user/signIn", consumes = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "UserE-Medicare",fallbackMethod="fallbackMethodSignIn")
    @Retry(name = "UserE-Medicare")
    String signIn(@RequestBody User user);

    @PostMapping(value = "/user/signUp", consumes = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "UserE-Medicare",fallbackMethod="fallbackMethodSignUp")
    @Retry(name = "UserE-Medicare")
    String signUp(@RequestBody User user);

    @PostMapping(value = "/user/changePassword", consumes = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "UserE-Medicare",fallbackMethod="fallbackMethodChangePassword")
    @Retry(name = "UserE-Medicare")
    String changePassword(@RequestBody User user);

    @DeleteMapping(value = "/user/deleteUser/{emailid}")
    @CircuitBreaker(name = "UserE-Medicare",fallbackMethod="fallbackMethodDeleteUser")
    @Retry(name = "UserE-Medicare")
    String deleteUser(@PathVariable("emailid") String emailid);

    @GetMapping(value = "/user/findAllUser")
    @CircuitBreaker(name = "UserE-Medicare",fallbackMethod="fallbackMethodFindAllUsers")
    @Retry(name = "UserE-Medicare")
    List<User> findAllUsers();

    // Default fallback method for signIn
    default String fallbackMethodSignIn(User user, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return "Sign-in failed"; // Return a default response or handle the error as needed.
    }

    // Default fallback method for signUp
    default String fallbackMethodSignUp(User user, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return "Sign-up failed"; // Return a default response or handle the error as needed.
    }

    // Default fallback method for changePassword
    default String fallbackMethodChangePassword(User user, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return "Change password failed"; // Return a default response or handle the error as needed.
    }

    // Default fallback method for deleteUser
    default String fallbackMethodDeleteUser(String emailid, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return "Delete user failed"; // Return a default response or handle the error as needed.
    }

    // Default fallback method for findAllUsers
    default List<User> fallbackMethodFindAllUsers(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());

        // Create a list of default User objects with predefined values
        List<User> defaultUsers = new ArrayList<>();
        
        User user1 = new User();
        user1.setEmailid(null);// Example: Set a default ID
        user1.setPassword(null);
        user1.setTypeOfUser(null);
        defaultUsers.add(user1);

        return defaultUsers;
}
}
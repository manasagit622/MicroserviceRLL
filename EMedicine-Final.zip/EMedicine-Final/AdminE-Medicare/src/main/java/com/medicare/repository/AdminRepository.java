package com.medicare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.medicare.bean.Admin;



@Repository("adminRepository")
public interface AdminRepository extends JpaRepository<Admin, Integer> {
	
	public Admin username(String username);
	public Admin findByUsernameAndPassword(String username, String password);

}


package com.medicare.controller;

import com.medicare.bean.Medicine;
import com.medicare.proxy.MedicineServiceProxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
@CrossOrigin
public class MedicineController {

    @Autowired
    private MedicineServiceProxy medicineServiceProxy;
    private Logger log = LoggerFactory.getLogger(MedicineController.class);
    // Store a new medicine product
    @PostMapping(value = "/storeProduct", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String storeProduct(@RequestBody Medicine medicine) {
        return medicineServiceProxy.storeProduct(medicine);
    }

    // Update an existing medicine product
    @PatchMapping(value = "/updateProduct", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String updateProduct(@RequestBody Medicine medicine) {
        return medicineServiceProxy.updateProduct(medicine);
    }

    // Get a list of all medicine products
    @GetMapping(value = "/findAllProduct", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Medicine> getAllProducts() {
        return medicineServiceProxy.getAllProducts();
    }

    // Find medicine products by price
    @GetMapping(value = "/findProductByPrice/{price}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Medicine> findProductByPrice(@PathVariable("price") float price) {
        return medicineServiceProxy.findProductByPrice(price);
    }

    // Find a specific medicine product by ID
    @GetMapping(value = "/findProductById/{pid}")
    public String findProductById(@PathVariable("pid") int pid) {
        return medicineServiceProxy.findProductById(pid);
    }

    // Delete a specific medicine product by ID
    @DeleteMapping(value = "/deleteProduct/{pid}")
    public String deleteProductById(@PathVariable("pid") int pid) {
        return medicineServiceProxy.deleteProduct(pid);
    }
}

package com.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.bean.Medicine;
import com.medicare.service.MedicineService;

@RestController
@RequestMapping("product")
@CrossOrigin
public class MedicineController {

	@Autowired
	MedicineService medicineService;
	
	@PostMapping(value = "storeProduct",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String storeProduct(@RequestBody Medicine medicine) {
		return medicineService.storeProduct(medicine);
	}
	
	@PatchMapping(value = "updateProduct",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Medicine medicine) {
		return medicineService.updateProduct(medicine);
	}
	
	@GetMapping(value="findAllProduct",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Medicine> getAllProduct() {
		return medicineService.getAllProducts();
	}
	
	@GetMapping(value="findProductByPrice/{price}",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Medicine> findProductByPrice(@PathVariable("price") float price) {
		return medicineService.findProductByPrice(price);
	}
	
	@GetMapping(value="findAllProduct/{pid}")
	public String findProductById(@PathVariable("pid") int pid) {
		return medicineService.findProductById(pid);
	}
	
	@DeleteMapping(value="deleteProduct/{pid}")
	public String deleteProductUsingId(@PathVariable("pid") int pid) {
		return medicineService.deleteProduct(pid);
	}
}

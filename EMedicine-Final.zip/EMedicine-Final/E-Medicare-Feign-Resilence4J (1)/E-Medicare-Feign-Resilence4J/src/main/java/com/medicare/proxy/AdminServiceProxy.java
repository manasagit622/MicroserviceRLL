package com.medicare.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import com.medicare.bean.Admin;
import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "AdminE-Medicare")
public interface AdminServiceProxy {

    @PostMapping("/admin/adminlogin")
    @CircuitBreaker(name = "AdminE-Medicare",fallbackMethod = "fallbackMethodLoginAdmin")
    @Retry(name = "AdminE-Medicare")
    Admin loginAdmin(@RequestBody Admin admin);

    @GetMapping("/admin/findall")
    @CircuitBreaker(name = "AdminE-Medicare",fallbackMethod = "fallbackMethodFindAllAdmins")
    @Retry(name = "AdminE-Medicare")
    List<Admin> findAllAdmins();

    // Add other methods as needed

    // Default fallback method for loginAdmin
    default Admin fallbackMethodLoginAdmin(Admin admin, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new Admin(); // Return a default response or handle the error as needed.
    }

    // Default fallback method for findAllAdmins
    default List<Admin> fallbackMethodFindAllAdmins(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        
        // You can return a default empty list or a list with some predefined default Admin objects
        List<Admin> defaultAdmins = new ArrayList<>();
        Admin admin1 = new Admin();
        admin1.setId(-1L); // Example: Set a default ID
        admin1.setUsername("FallMethodApplied"); // Example: Set a default username
        admin1.setPassword("FallMethodPassword"); // Example: Set a default email
        defaultAdmins.add(admin1);

        
        return defaultAdmins;
    }
}
package com.medicare.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.medicare.bean.User;

import java.util.List;

import com.medicare.proxy.UserServiceProxy;

@RestController
@RequestMapping("user")
@CrossOrigin
public class UserController {

    @Autowired
    UserServiceProxy userServiceProxy;
    private Logger log = LoggerFactory.getLogger(UserController.class);
    
    @PostMapping(value = "signIn", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String signIn(@RequestBody User user) {
        return userServiceProxy.signIn(user);
    }

    @PostMapping(value = "signUp", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String signUp(@RequestBody User user) {
        return userServiceProxy.signUp(user);
    }

    @PostMapping(value = "changePassword", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String changePassword(@RequestBody User user) {
        return userServiceProxy.changePassword(user);
    }

    @DeleteMapping(value = "deleteUser/{emailid}")
    public String deleteUserUsingEmailId(@PathVariable("emailid") String emailid) {
        return userServiceProxy.deleteUser(emailid);
    }

    @GetMapping(value = "findAllUser")
    public List<User> findAllUser() {
        return userServiceProxy.findAllUsers();
    }
}

package com.medicare.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.medicare.bean.CreditCard;
import com.medicare.proxy.CreditCardServiceProxy;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/creditcards")
public class CreditCardController {

    private final CreditCardServiceProxy creditCardServiceProxy;

    @Autowired
    public CreditCardController(CreditCardServiceProxy creditCardServiceProxy) {
        this.creditCardServiceProxy = creditCardServiceProxy;
    }
    private Logger log = LoggerFactory.getLogger(CreditCardController.class);
    @PostMapping
    public ResponseEntity<CreditCard> createCreditCard(@RequestBody CreditCard creditCard) {
        CreditCard createdCreditCard = creditCardServiceProxy.createCreditCard(creditCard);
        return new ResponseEntity<>(createdCreditCard, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<CreditCard>> getAllCreditCards() {
        List<CreditCard> creditCards = creditCardServiceProxy.getAllCreditCards();
        return new ResponseEntity<>(creditCards, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CreditCard> getCreditCardById(@PathVariable Long id) {
        Optional<CreditCard> creditCard = creditCardServiceProxy.getCreditCardById(id);
        return creditCard.map(card -> new ResponseEntity<>(card, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCreditCard(@PathVariable Long id) {
        creditCardServiceProxy.deleteCreditCard(id);
        return new ResponseEntity<>("Credit card deleted successfully", HttpStatus.OK);
    }

    // Add more credit card-related API endpoints as needed
}

package com.medicare.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.bean.Admin;
import com.medicare.proxy.AdminServiceProxy;

import java.util.List;

@RestController
@Controller
@Scope("request")
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminServiceProxy adminServiceProxy; // Inject the Feign client
    private Logger log = LoggerFactory.getLogger(AdminController.class);

    // Your other controller methods

    @PostMapping("/adminlogin")
    public Admin loginuser(@RequestBody Admin admin) throws Exception {
        try {
            return adminServiceProxy.loginAdmin(admin);
        } catch (Exception e) {
            throw new Exception("Bad Credentials");
        }
    }

    // Add the findAll method here
    @GetMapping("/findall")
    public List<Admin> findAll() {
        // Use the Feign client to fetch the list of admins
    	log.debug("Received request to retrieve all admins");
        return adminServiceProxy.findAllAdmins();
    }

    // Other controller methods
}

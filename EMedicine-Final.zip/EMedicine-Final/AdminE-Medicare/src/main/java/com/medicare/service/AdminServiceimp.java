package com.medicare.service;



import java.util.List;

import com.medicare.bean.Admin;




public interface AdminServiceimp {

	Admin findByUsername(String username);
	void save(Admin admin);
	List<Admin> findAll();
	Admin findByUsernameAndPassword(String username, String password);

}
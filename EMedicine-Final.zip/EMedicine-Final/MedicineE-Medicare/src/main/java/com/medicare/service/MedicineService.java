package com.medicare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.bean.Medicine;
import com.medicare.repository.MedicineRepository;

@Service
public class MedicineService {

	@Autowired
	MedicineRepository medicineRepository;
	
	public String storeProduct(Medicine medicine) {
		medicineRepository.save(medicine);
		return "Product details stored";
	}
	
	public List<Medicine> getAllProducts() {
		return medicineRepository.findAll();
	}
	
	public String findProductById(int pid) {
		Optional<Medicine> result  = medicineRepository.findById(pid);
		if(result.isPresent()) {
			Medicine p = result.get();
			return p.toString();
		}else {
			return "Product not found";
		}
	}
	
	public List<Medicine> findProductByPrice(float price){
		return medicineRepository.findProductByPrice(price);
	}
	
	public String deleteProduct(int pid) {
		Optional<Medicine> result  = medicineRepository.findById(pid);
		if(result.isPresent()) {
			Medicine p = result.get();
			medicineRepository.delete(p);
			return "Product deleted successfully";
		}else {
			return "Product not found";
		}
	}
	
	public String updateProduct(Medicine medicine) {
		Optional<Medicine> result  = medicineRepository.findById(medicine.getPid());
		if(result.isPresent()) {
			Medicine p = result.get();
			p.setPrice(medicine.getPrice());
			p.setUrl(medicine.getUrl());
			p.setType(medicine.getType());
			p.setDescription(medicine.getDescription());
			medicineRepository.saveAndFlush(p);
			return "Product updated successfully";
		}else {
			return "Product not found";
		}
	}
}

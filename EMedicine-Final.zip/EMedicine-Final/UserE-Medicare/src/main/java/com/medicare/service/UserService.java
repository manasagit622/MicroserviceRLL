package com.medicare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.bean.User;
import com.medicare.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;

	public String signIn(User user) {
		Optional<User> result = userRepository.findById(user.getEmailid());
		if (result.isPresent()) {
			User ll = result.get();
			if (ll.getPassword().equals(user.getPassword())) {

				if (user.getTypeOfUser().equals(ll.getTypeOfUser()) && user.getTypeOfUser().equals("admin")) {
					return "Admin sucessfully login";
				} else if (user.getTypeOfUser().equals(ll.getTypeOfUser()) && user.getTypeOfUser().equals("user")) {
					return "User successfully login";
				} else {
					return "Invalid details";
				}
			} else {
				return "InValid password";
			}
		} else {
			return "InValid emailId";
		}
	}

	public String signUp(User user) {
		Optional<User> result = userRepository.findById(user.getEmailid());
		if (result.isPresent()) {
			return "Email Id alreay exists";
		} else {
			if (user.getTypeOfUser().equals("admin")) {
				return "You can't create admin account";
			} else {
				userRepository.save(user);
				return "Account created successfully";
			}

		}
	}

	public String changePassword(User user) {

		String email = user.getEmailid();
		String password = user.getPassword();
		if (email != null && password != null) {
			Optional<User> result = userRepository.findById(email);
			if (result.isPresent()) {
				User newLogin = result.get();
				newLogin.setPassword(password);

				userRepository.save(newLogin);

				return "password changed successfully";
			} else {
				return "user doest not exist";
			}
		}
		else {
			return "Please enter your emailId and password";
		}
	}
	
	public String deleteusers(String emailid) {
		Optional<User> result = userRepository.findById(emailid);
		if (result.isPresent()) {
			User l = result.get();
			userRepository.delete(l);
			return "User deleted successfully";
		} else {
			return "user not present";
		}
	}

	public List<User> findAllUser() {
		List<User> result = userRepository.findBytypeOfUser("user");
		return result;
	}
}
package com.medicare.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.medicare.bean.CreditCard;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@FeignClient(name = "PaymentE-Medicare") // Name of the service you want to consume (replace with actual service name)
public interface CreditCardServiceProxy {

    @PostMapping(value = "/api/creditcards", consumes = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "PaymentE-Medicare", fallbackMethod = "fallbackCreateCreditCard")
    @Retry(name = "PaymentE-Medicare")
    CreditCard createCreditCard(@RequestBody CreditCard creditCard);

    @GetMapping(value = "/api/creditcards", produces = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "PaymentE-Medicare", fallbackMethod = "fallbackGetAllCreditCards")
    @Retry(name = "PaymentE-Medicare")
    List<CreditCard> getAllCreditCards();

    @GetMapping(value = "/api/creditcards/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "PaymentE-Medicare", fallbackMethod = "fallbackGetCreditCardById")
    @Retry(name = "PaymentE-Medicare")
    Optional<CreditCard> getCreditCardById(@PathVariable Long id);

    @DeleteMapping(value = "/api/creditcards/{id}")
    @CircuitBreaker(name = "PaymentE-Medicare", fallbackMethod = "fallbackDeleteCreditCard")
    @Retry(name = "PaymentE-Medicare")
    void deleteCreditCard(@PathVariable Long id);

    // Add other methods as needed

    // Default fallback method for createCreditCard
    default CreditCard fallbackCreateCreditCard(CreditCard creditCard, Throwable cause) {
        System.out.println("Exception raised in createCreditCard: " + cause.getMessage());
        return new CreditCard(); // Return a default response or handle the error as needed.
    }

    default List<CreditCard> fallbackGetAllCreditCards(Throwable cause) {
        System.out.println("Exception raised in getAllCreditCards: " + cause.getMessage());
        
        // You can return a default list of CreditCard objects with predefined values
        List<CreditCard> defaultCreditCards = new ArrayList<>();
        CreditCard card1 = new CreditCard();
        card1.setId(-1L); // Example: Set a default ID
        card1.setCardNumber("Fallback Method"); // Example: Set a default card number
        card1.setCardHolderName("FallbackMethodName");
        card1.setExpirationDate("00/00/0000");
        // Set other properties as needed
        defaultCreditCards.add(card1);

        CreditCard card2 = new CreditCard();
        card2.setId(-2L); // Example: Set a default ID
        card2.setCardNumber("defaultCardNumber2"); // Example: Set a default card number
        card2.setCardHolderName("FallbackMethodName");
        card2.setExpirationDate("00/00/0000");
        defaultCreditCards.add(card2);

        return defaultCreditCards;
    }

    // Default fallback method for getCreditCardById
    default Optional<CreditCard> fallbackGetCreditCardById(Long id, Throwable cause) {
        System.out.println("Exception raised in getCreditCardById: " + cause.getMessage());
        
        // You can return a default empty Optional or a default CreditCard object
        CreditCard defaultCard = new CreditCard();
        defaultCard.setId(-1L); // Example: Set a default ID
        defaultCard.setCardNumber("defaultCardNumber"); // Example: Set a default card number
        // Set other properties as needed
        
        return Optional.of(defaultCard);
    }


    // Default fallback method for deleteCreditCard
    default void fallbackDeleteCreditCard(Long id, Throwable cause) {
        System.out.println("Exception raised in deleteCreditCard: " + cause.getMessage());
        // Handle the error as needed (e.g., log the error)
    }

    // Add default fallback methods for other service methods as needed
}

package com.medicare.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.medicare.bean.Order;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@FeignClient(name = "OrderE-Medicare") // Name of the service you want to consume (replace with actual service name)
public interface OrderServiceProxy {

    @PostMapping(value = "/api/orders/create", consumes = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "OrderE-Medicare", fallbackMethod = "fallbackCreateOrder")
    @Retry(name = "OrderE-Medicare")
    Order createOrder(@RequestBody Order order);

    @GetMapping(value = "/api/orders/all", produces = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "OrderE-Medicare", fallbackMethod = "fallbackGetAllOrders")
    @Retry(name = "OrderE-Medicare")
    List<Order> getAllOrders();

    @GetMapping(value = "/api/orders/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "OrderE-Medicare", fallbackMethod = "fallbackGetOrderById")
    @Retry(name = "OrderE-Medicare")
    Order getOrderById(@PathVariable Long id);

    // Add other methods as needed

    // Default fallback method for createOrder
    default Order fallbackCreateOrder(Order order, Throwable cause) {
        System.out.println("Exception raised in createOrder: " + cause.getMessage());
        return new Order(); // Return a default response or handle the error as needed.
    }

    // Default fallback method for getAllOrders
    default List<Order> fallbackGetAllOrders(Throwable cause) {
        System.out.println("Exception raised in getAllOrders: " + cause.getMessage());

        // Create a list of default Order objects with predefined values
        List<Order> defaultOrders = new ArrayList<>();
        Order defaultOrder = new Order();
        defaultOrder.setId(-1L); // Example: Set a default ID
        defaultOrder.setQuantity(0);
        defaultOrder.setProductId(null);
        defaultOrder.setUserId(null);
        Order order1 = new Order();
        
        // Set other properties as needed
        defaultOrders.add(order1);

       

        return defaultOrders;
    }

    // Default fallback method for getOrderById
    default Order fallbackGetOrderById(Long id, Throwable cause) {
        System.out.println("Exception raised in getOrderById: " + cause.getMessage());

        // You can return a default Order object with predefined values
        Order defaultOrder = new Order();
        defaultOrder.setId(-1L); // Example: Set a default ID
        defaultOrder.setQuantity(0);
        defaultOrder.setProductId(id);
        defaultOrder.setUserId(id);
        return defaultOrder;
    }

    // Add default fallback methods for other service methods as needed
}

package com.medicare.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.medicare.bean.Payment;
import com.medicare.proxy.PaymentServiceProxy;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentServiceProxy paymentServiceProxy;

    @Autowired
    public PaymentController(PaymentServiceProxy paymentServiceProxy) {
        this.paymentServiceProxy = paymentServiceProxy;
    }
    private Logger log = LoggerFactory.getLogger(PaymentController.class);
    @PostMapping
    @CircuitBreaker(name = "createPaymentCircuitBreaker")
    @Retry(name = "createPaymentRetry")
    public ResponseEntity<Payment> createPayment(@RequestBody Payment payment) {
        Payment createdPayment = paymentServiceProxy.createPayment(payment);
        return new ResponseEntity<>(createdPayment, HttpStatus.CREATED);
    }

    @GetMapping
    @CircuitBreaker(name = "getAllPaymentsCircuitBreaker")
    @Retry(name = "getAllPaymentsRetry")
    public ResponseEntity<List<Payment>> getAllPayments() {
        List<Payment> payments = paymentServiceProxy.getAllPayments();
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @CircuitBreaker(name = "getPaymentByIdCircuitBreaker")
    @Retry(name = "getPaymentByIdRetry")
    public ResponseEntity<Optional<Payment>> getPaymentById(@PathVariable Long id) {
        Optional<Payment> payment = paymentServiceProxy.getPaymentById(id);
        
        if (payment.isPresent()) {
            return new ResponseEntity<>(payment, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    @CircuitBreaker(name = "deletePaymentCircuitBreaker")
    @Retry(name = "deletePaymentRetry")
    public ResponseEntity<Void> deletePayment(@PathVariable Long id) {
        paymentServiceProxy.deletePayment(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Add more payment-related API endpoints as needed
}

package com.medicare.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import com.medicare.bean.Payment;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "PaymentE-Medicare") // Name of the payment service you want to consume
public interface PaymentServiceProxy {

    @PostMapping("/api/payments")
    @CircuitBreaker(name = "PaymentE-Medicare",fallbackMethod = "fallbackMethodCreatePayment")
    @Retry(name = "PaymentE-Medicare")
    Payment createPayment(@RequestBody Payment payment);

    @GetMapping("/api/payments")
    @CircuitBreaker(name = "PaymentE-Medicare",fallbackMethod ="fallbackMethodGetAllPayments")
    @Retry(name = "PaymentE-Medicare")
    List<Payment> getAllPayments();

    @GetMapping("/api/payments/{id}")
    @CircuitBreaker(name = "PaymentE-Medicare",fallbackMethod="fallbackMethodGetPaymentById")
    @Retry(name = "PaymentE-Medicare")
    Optional<Payment> getPaymentById(@PathVariable("id") Long id);

    @DeleteMapping("/api/payments/{id}")
    @CircuitBreaker(name = "PaymentE-Medicare",fallbackMethod="fallbackMethodDeletePayment")
    @Retry(name = "PaymentE-Medicare")
    void deletePayment(@PathVariable("id") Long id);

    // Default fallback method for createPayment
    default Payment fallbackMethodCreatePayment(Payment payment, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new Payment(); // Return a default response or handle the error as needed.
    }

    // Default fallback method for getAllPayments
    default List<Payment> fallbackMethodGetAllPayments(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return Collections.emptyList(); // Return an empty list or handle the error as needed.
    }

    // Default fallback method for getPaymentById
    default Optional<Payment> fallbackMethodGetPaymentById(Long id, Throwable cause) {
        System.out.println("Exception raised in getPaymentById: " + cause.getMessage());

        // You can return a default empty Optional or a default Payment object
        Payment defaultPayment = new Payment();
        defaultPayment.setId(-1L); // Example: Set a default ID
        defaultPayment.setPaymentMethod(null); // Example: Set a default amount
        defaultPayment.setAmount(000);

        return Optional.of(defaultPayment); // Return an empty Optional or handle the error as needed.
    }

    // Default fallback method for deletePayment
    default void fallbackMethodDeletePayment(Long id, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        // Handle the error as needed, such as logging.
    }
}

package com.medicare.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.bean.*;
import com.medicare.service.AdminService;


@RestController
@Controller
@Scope("request")
@RequestMapping("/admin")
public class AdminController {
	
    @Autowired
    @Qualifier("adminService")
	private AdminService adminservice;
    
    
    @GetMapping(value="/")
    public String check() {
    	return "Welcome......"; 
    }
    
    
    @PostMapping("/adminlogin")
	public Admin loginuser(@RequestBody Admin admin) throws Exception {
		String tempusername = admin.getusername();
		String tempPass=admin.getPassword();
		Admin adminObj = null;
		if(tempusername != null && tempPass != null ) {
			
			adminObj = adminservice.findByUsernameAndPassword(tempusername, tempPass);
					
		}
		if(adminObj ==null) {
			throw new Exception("Bad  Credentials");
		}
			
		return adminObj;
	
	}
    
    
	@GetMapping(value="/findall" ,produces={MediaType.APPLICATION_JSON_VALUE})
	public List<Admin> findAll(){
		return adminservice.findAll();
	}

}
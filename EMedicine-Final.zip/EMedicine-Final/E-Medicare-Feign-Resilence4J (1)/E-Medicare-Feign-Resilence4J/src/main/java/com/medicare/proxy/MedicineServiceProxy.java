package com.medicare.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.medicare.bean.Medicine;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@FeignClient(name = "MedicineE-Medicare") // Name of the service you want to consume
public interface MedicineServiceProxy {

    @PostMapping(value = "/product/storeProduct", consumes = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "MedicineE-Medicare", fallbackMethod = "fallbackStoreProduct")
    @Retry(name = "MedicineE-Medicare")
    String storeProduct(@RequestBody Medicine medicine);

    @PatchMapping(value = "/product/updateProduct", consumes = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "MedicineE-Medicare", fallbackMethod = "fallbackUpdateProduct")
    @Retry(name = "MedicineE-Medicare")
    String updateProduct(@RequestBody Medicine medicine);

    @GetMapping(value = "/product/findAllProduct", produces = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "MedicineE-Medicare", fallbackMethod = "fallbackFindAllProducts")
    @Retry(name = "MedicineE-Medicare")
    List<Medicine> getAllProducts();

    @GetMapping(value = "/product/findProductByPrice/{price}", produces = MediaType.APPLICATION_JSON_VALUE)
    @CircuitBreaker(name = "MedicineE-Medicare", fallbackMethod = "fallbackFindProductByPrice")
    @Retry(name = "MedicineE-Medicare")
    List<Medicine> findProductByPrice(@PathVariable("price") float price);

    @GetMapping(value = "/product/findAllProduct/{pid}")
    @CircuitBreaker(name = "MedicineE-Medicare", fallbackMethod = "fallbackFindProductById")
    @Retry(name = "MedicineE-Medicare")
    String findProductById(@PathVariable("pid") int pid);

    @DeleteMapping(value = "/product/deleteProduct/{pid}")
    @CircuitBreaker(name = "MedicineE-Medicare", fallbackMethod = "fallbackDeleteProduct")
    @Retry(name = "MedicineE-Medicare")
    String deleteProduct(@PathVariable("pid") int pid);

    // Default fallback method for all Feign client methods
    default String fallbackStoreProduct(Throwable cause) {
        System.out.println("Exception raised in storeProduct: " + cause.getMessage());
        return "Fallback response for storeProduct";
    }

    default String fallbackUpdateProduct(Throwable cause) {
        System.out.println("Exception raised in updateProduct: " + cause.getMessage());
        return "Fallback response for updateProduct";
    }

 // Default fallback method for getAllProducts
    default List<Medicine> fallbackFindAllProducts(Throwable cause) {
        System.out.println("Exception raised in getAllProducts: " + cause.getMessage());
        
        // You can return a default list of Medicine objects with predefined values
        List<Medicine> defaultMedicines = new ArrayList<>();
        
        // Create some default Medicine objects
        Medicine medicine1 = new Medicine();
        medicine1.setPid(-1L); // Example: Set a default ID
        medicine1.setType("DefaultMedicine1"); // Example: Set a default name
        medicine1.setPname("DefaultMedicine1");
        medicine1.setPrice(0000);
        medicine1.setUrl("DefaultMedicine1");
        defaultMedicines.add(medicine1);
        
        return defaultMedicines;
    }

 // Default fallback method for findProductByPrice
    default List<Medicine> fallbackFindProductByPrice(float price, Throwable cause) {
        System.out.println("Exception raised in findProductByPrice: " + cause.getMessage());
        
        // You can return a default list of Medicine objects with predefined values
        List<Medicine> defaultMedicines = new ArrayList<>();
        
        // Create some default Medicine objects
        Medicine medicine1 = new Medicine();
        medicine1.setPid(-1L); // Example: Set a default ID
        medicine1.setType("DefaultMedicine1"); // Example: Set a default name
        medicine1.setPname("DefaultMedicine1");
        medicine1.setPrice(0000);
        medicine1.setUrl("DefaultMedicine1");
        defaultMedicines.add(medicine1);
        return defaultMedicines;
 }

 // Default fallback method for findProductById
    default String fallbackFindProductById(int pid, Throwable cause) {
        System.out.println("Exception raised in findProductById: " + cause.getMessage());
        
        // You can return a default error message or handle the error as needed.
        return "Product with ID " + pid + " not found";
    }


    default String fallbackDeleteProduct(int pid, Throwable cause) {
        System.out.println("Exception raised in deleteProduct: " + cause.getMessage());
        return "Fallback response for deleteProduct";
    }
}
